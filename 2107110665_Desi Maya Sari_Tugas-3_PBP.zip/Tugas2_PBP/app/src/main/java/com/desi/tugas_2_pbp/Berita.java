package com.desi.tugas_2_pbp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Berita extends AppCompatActivity {
    TextView textuser;
    ListView lisView;
    String[] Halaman = {"Beranda", "Galeri", "Berita", "Kontak"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        lisView = findViewById(R.id.LisView);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Halaman);
        lisView.setAdapter(adapter);

        lisView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String userpick = (String) adapterView.getItemAtPosition(i);
                switch (userpick) {
                    case "Beranda" :
                        Intent intent = new Intent( Berita.this,home.class);
                        startActivity(intent);
                        break;

                    case "Berita":
                        Toast.makeText(Berita.this, "anda sudah berada di halaman"+userpick, Toast.LENGTH_SHORT).show();
                        break;

                    case "Galeri":
                        Intent intent1 = new Intent( Berita.this,Galeri.class);
                        startActivity(intent1);
                        break;

                    case "Kontak":
                        Intent intent2 = new Intent( Berita.this,Kontak.class);
                        startActivity(intent2);
                        break;
                }
            }
        });
    }
}