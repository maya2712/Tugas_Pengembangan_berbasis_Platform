package com.desi.tugas_2_pbp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Kontak extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kontak);
    }
}