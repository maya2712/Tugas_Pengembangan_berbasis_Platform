package id.ac.unri.navapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CursorAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class CustomListViewActivity extends AppCompatActivity {

    ListView customListView;
    List listKonten = new ArrayList();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_list_view);

        customListView = findViewById(R.id.customListView);

        Konten konten1 = new Konten(R.drawable.gambar1, "11/03/2023", "Baba", getResources().getString(R.string.lorem));
        Konten konten2 = new Konten(R.drawable.gambar2, "12/03/2023", "Bibi",  getResources().getString(R.string.lorem) );
        Konten konten3 = new Konten(R.drawable.gambar3, "13/03/2023", "Bubu", getResources().getString(R.string.lorem));
        Konten konten4 = new Konten(R.drawable.gambar4, "14/03/2023", "Bebe", getResources().getString(R.string.lorem));
        Konten konten5 = new Konten(R.drawable.gambar5, "15/03/2023", "Bobo", getResources().getString(R.string.lorem));

        listKonten.add(konten1);
        listKonten.add(konten2);
        listKonten.add(konten3);
        listKonten.add(konten4);
        listKonten.add(konten5);

        CustomAdapter adapter = new CustomAdapter(this, R.layout.single_list_item,listKonten);
        customListView.setAdapter(adapter);
    }
}