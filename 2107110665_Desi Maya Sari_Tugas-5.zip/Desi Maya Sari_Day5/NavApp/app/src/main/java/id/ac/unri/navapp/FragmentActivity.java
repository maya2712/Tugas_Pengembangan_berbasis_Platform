package id.ac.unri.navapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import id.ac.unri.navapp.Fragment.Fragment1;
import id.ac.unri.navapp.Fragment.Fragment2;
import id.ac.unri.navapp.Fragment.Fragment3;
import id.ac.unri.navapp.Fragment.FragmentStateAdapter;

public class FragmentActivity extends AppCompatActivity {

    ViewPager viewPager; ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment);

        viewPager = findViewById(R.id.viewPager);
        setupViewPager(viewPager);
    }

    private void setupViewPager(ViewPager viewPager) {
        FragmentStateAdapter adapter = new FragmentStateAdapter(getSupportFragmentManager());
        adapter.addFragment(new Fragment1(),"INI Fragment 1");
        adapter.addFragment(new Fragment2(),"Ini Fragment 2");
        adapter.addFragment(new Fragment3(), "Ini Fragment 3");
        viewPager.setAdapter(adapter);
    }

    public void setPage(int page){
        viewPager.setCurrentItem(page);
    }
}