package com.desi.tugas_2_pbp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class home extends AppCompatActivity {
    TextView textuser;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        textuser = findViewById(R.id.txtuser);
        /*Intent i = getIntent();
        String i_extra = i.getStringExtra("email");
        textuser.setText(i_extra);*/

        textuser.setText(getIntent().getStringExtra("email"));
    }
}