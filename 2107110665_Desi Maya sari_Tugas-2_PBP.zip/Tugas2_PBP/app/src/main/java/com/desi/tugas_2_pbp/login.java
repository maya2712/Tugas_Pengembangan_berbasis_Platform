package com.desi.tugas_2_pbp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.wifi.hotspot2.pps.HomeSp;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity {
    Button btnlogin;
    Button btnRegister;
    EditText email,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnlogin = findViewById(R.id.btnlogin);
        email = findViewById(R.id.etusername);
        password = findViewById(R.id.etPassword);
        btnRegister = findViewById(R.id.btnRegister);



        btnlogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                String str_email = email.getText().toString();
                String str_pass = password.getText().toString();
                Intent trima = getIntent();
                String trima_email = trima.getStringExtra("email");
                String trima_pass = trima.getStringExtra("password");
                if(str_email.equals(trima_email)&&str_pass.equals(trima_pass)){
                    Intent intent = new Intent(login.this, home.class);
                    intent.putExtra("email", str_email);
                    startActivity(intent);
                }else{
                    Toast.makeText(login.this, "Username atau password salah", Toast.LENGTH_SHORT).show();
                }

            }
        });
        btnRegister.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent(login.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }
}