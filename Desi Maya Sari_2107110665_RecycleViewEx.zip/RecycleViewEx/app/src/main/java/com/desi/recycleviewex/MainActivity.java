package com.desi.recycleviewex;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private Button btnStandarRc, btnStaggeredRc, btnHorizontalRc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnStandarRc = findViewById(R.id.btn_standar);
        btnStaggeredRc = findViewById(R.id.btn_staggered);
        btnHorizontalRc = findViewById(R.id.btn_horizontal);

        btnStandarRc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i_standar = new  Intent(MainActivity.this, StandarRecycleView.class);
                startActivity(i_standar);
            }
        });
        btnHorizontalRc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i_horizontal = new Intent(MainActivity.this, HorizontalRecycleView.class);
                startActivity(i_horizontal);
            }
        });

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_standar:
                Intent i_standar = new Intent(MainActivity.this, StandarRecycleView.class);
                startActivity(i_standar);
                break;
            case R.id.btn_staggered:
                Intent i_staggered = new Intent(MainActivity.this, StandarRecycleView.class);
                startActivity(i_staggered);
                break;
            case R.id.btn_horizontal:
                Intent i_horizontal = new Intent(MainActivity.this, StandarRecycleView.class);
                startActivity(i_horizontal);
                break;
        }
    }
}