package com.desi.recycleviewex;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.desi.recycleviewex.adapters.StandarRecycleViewAdapter;

import java.util.ArrayList;

public class StandarRecycleView extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<String> ar_title = new ArrayList<>();
    ArrayList<Integer> ar_image = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_standar_recycle_view);

        recyclerView = findViewById(R.id.recycleview);

        ar_image.add(R.drawable.kucing);
        ar_title.add("Foto Kucing 1");

        ar_image.add(R.drawable.kucing3);
        ar_title.add("Foto Kucing 2");

        ar_image.add(R.drawable.kucing4);
        ar_title.add("Foto Kucing 3");

        ar_image.add(R.drawable.kucing6);
        ar_title.add("Foto Kucing 4");

        ar_image.add(R.drawable.kucing8);
        ar_title.add("Foto Kucing 5");

        ar_image.add(R.drawable.kkucing3);
        ar_title.add("Foto Kucing 6");

        ar_image.add(R.drawable.kucing_i);
        ar_title.add("Foto  Kucing 7");

        ar_image.add(R.drawable.kucing4);
        ar_title.add("Foto Kucing 8");

        ar_image.add(R.drawable.kucing10);
        ar_title.add("Foto Kucing 9");

        ar_image.add(R.drawable.kucing);
        ar_title.add("Foto Kucing 10");


        StandarRecycleViewAdapter adapter = new StandarRecycleViewAdapter(StandarRecycleView.this, ar_title, ar_image);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(StandarRecycleView.this));
    }
}
