package com.desi.recycleviewex;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class HorizontalRecycleView extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_horizontal_recycle_view);
    }
}
