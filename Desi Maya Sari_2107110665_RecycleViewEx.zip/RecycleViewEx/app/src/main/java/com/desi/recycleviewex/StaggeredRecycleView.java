package com.desi.recycleviewex;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class StaggeredRecycleView extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staggered_recycle_view);
    }
}
