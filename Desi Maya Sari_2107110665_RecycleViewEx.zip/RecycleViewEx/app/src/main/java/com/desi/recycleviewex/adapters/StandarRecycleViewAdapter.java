package com.desi.recycleviewex.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.desi.recycleviewex.R;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class StandarRecycleViewAdapter extends RecyclerView.Adapter<StandarRecycleViewAdapter.ViewHolder>{

    private Context context;
    private ArrayList<String> img_title = new ArrayList<>();
    private ArrayList<Integer> img_id = new ArrayList<>();

    public StandarRecycleViewAdapter(Context context, ArrayList<String> img_title, ArrayList<Integer> img_id) {
        this.context = context;
        this.img_title = img_title;
        this.img_id = img_id;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.single_standar_rv,parent,false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        holder.textView.setText(img_title.get(position));
        holder.circleImageView.setImageResource(img_id.get(position));
        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "Anda mengklik : "+img_title.get(position), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return img_id.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        LinearLayout linearLayout;
        CircleImageView circleImageView;
        TextView textView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            linearLayout = itemView.findViewById(R.id.linearlayout);
            circleImageView = itemView.findViewById(R.id.image);
            textView = itemView.findViewById(R.id.img_title);
        }
    }
}